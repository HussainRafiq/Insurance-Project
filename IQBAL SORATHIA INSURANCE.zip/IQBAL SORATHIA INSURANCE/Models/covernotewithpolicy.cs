﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IQBAL_SORATHIA_INSURANCE.Models
{
    public class covernotewithpolicy
    {
        public policy pol { get; set; }
        public marinecover man { get; set; }
    }
}