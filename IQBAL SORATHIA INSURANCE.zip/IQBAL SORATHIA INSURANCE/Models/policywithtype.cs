﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IQBAL_SORATHIA_INSURANCE.Models
{
    public class policywithtype
    {

        public policy pol { get; set; }
        public type typ { get; set; }
        public receipt rep { get; set; }
    }
}